/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package archivos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import modelo.RegistroSalonFama;

/**
 *
 * @author pichilla
 */
public class ArchivoSalonFama {

    private File archivo;

    public ArchivoSalonFama(String nombreArchivo) {
        archivo = new File(nombreArchivo);
    }

    public void guardarRegistro(RegistroSalonFama registro)
            throws IOException {

        if (registro == null) {
            throw new IllegalArgumentException(
                    "El registro no puede ser null."
            );
        }

        try (BufferedWriter escritor = new BufferedWriter(
                new FileWriter(archivo, true))) {

            escritor.write(registro.getTexto());
            escritor.newLine();
        }
    }

    public String leerRegistros() throws IOException {

        if (!archivo.exists()) {
            return "Todavia no hay entrenadores en el Salon de la Fama.";
        }

        String contenido = "";

        try (BufferedReader lector = new BufferedReader(
                new FileReader(archivo))) {

            String linea;

            while ((linea = lector.readLine()) != null) {
                contenido += linea + "\n";
            }
        }

        if (contenido.trim().isEmpty()) {
            return "Todavia no hay entrenadores en el Salon de la Fama.";
        }

        return contenido;
    }
}
